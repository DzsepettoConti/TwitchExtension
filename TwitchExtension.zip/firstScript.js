console.log("Script loaded")
document.getElementById("NextHTMLbutton").addEventListener("click", function() {
    window.location.href = "index.html"})